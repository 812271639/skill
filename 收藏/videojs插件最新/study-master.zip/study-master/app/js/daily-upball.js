$(function(){
  
  // 快速打卡
  $("#container").on('click', '.status-normal', function(){

    $.prompt('点击了快速打卡，将进行快速打卡操作。');

    // 打卡相关操作
    
  });

});



