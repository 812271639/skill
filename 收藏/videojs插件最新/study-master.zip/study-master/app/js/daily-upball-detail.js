$(function(){
  
  // 加入！
  $('.join-button').on('click', function(){

    $.prompt('点击了加入操作，将进行打卡操作。');

    // 打卡相关操作
    
  });
  
});



