require("./index.scss");
require("../common/common.js");

//console.log("client/page1/index.js");
//console.log(module.hot)
var drawEl = document.getElementById("draw");
drawEl.innerHTML = "pekoa";

// Uncomment these to enable hot module reload for this entry.
// if (module.hot) {
//   module.hot.accept();
// }
