
console.log("common.js");