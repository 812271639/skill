
module.exports ={
	app:['./app/app.jsx','./asset/main.styl'],
	vender:['./app/jquery.js']
}