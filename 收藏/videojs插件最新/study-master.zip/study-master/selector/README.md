# 下拉选择框

* 模拟下拉选择框

## 演示地址

<http://sandbox.runjs.cn/show/eoc1gtit>